<!DOCTYPE html>
<html>

<head>
    <!-- Site made with Mobirise Website Builder v4.10.7, https://mobirise.com -->
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="generator" content="Mobirise v4.10.7, mobirise.com">
    <meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1">
    <link rel="shortcut icon" href="<?= base_url('assets/'); ?>landingpage/images/akucintakemensos1-122x122.jpg" type="image/x-icon">
    <meta name="description" content="">


    <!-- link dari mobirize-->
    <link rel="stylesheet" href="<?= base_url('assets/'); ?>landingpage/web/assets/mobirise-icons2/mobirise2.css">
    <link rel="stylesheet" href="<?= base_url('assets/'); ?>landingpage/web/assets/mobirise-icons/mobirise-icons.css">
    <link rel="stylesheet" href="<?= base_url('assets/'); ?>landingpage/tether/tether.min.css">
    <link rel="stylesheet" href="<?= base_url('assets/'); ?>landingpage/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="<?= base_url('assets/'); ?>landingpage/bootstrap/css/bootstrap-grid.min.css">
    <link rel="stylesheet" href="<?= base_url('assets/'); ?>landingpage/bootstrap/css/bootstrap-reboot.min.css">
    <link rel="stylesheet" href="<?= base_url('assets/'); ?>landingpage/dropdown/css/style.css">
    <link rel="stylesheet" href="<?= base_url('assets/'); ?>landingpage/socicon/css/styles.css">
    <link rel="stylesheet" href="<?= base_url('assets/'); ?>landingpage/theme/css/style.css">
    <link rel="stylesheet" href="<?= base_url('assets/'); ?>landingpage/gallery/style.css">
    <link rel="stylesheet" href="<?= base_url('assets/'); ?>landingpage/mobirise/css/mbr-additional.css" type="text/css">

</head>

<body>
    <section class="menu cid-rxUmTjJ62h" once="menu" id="menu1-0">



        <nav class="navbar navbar-expand beta-menu navbar-dropdown align-items-center navbar-fixed-top navbar-toggleable-sm bg-color transparent">
            <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <div class="hamburger">
                    <span></span>
                    <span></span>
                    <span></span>
                    <span></span>
                </div>
            </button>
            <div class="menu-logo">
                <div class="navbar-brand">
                    <span class="navbar-logo">
                        <a href="<?= base_url('auth/home'); ?>">
                            <img src="<?= base_url('assets/'); ?>landingpage/images/akucintakemensos1-122x122.jpg" alt="Image" title="" style="height: 4.1rem;">
                        </a>
                    </span>
                    <span class="navbar-caption-wrap"><a class="navbar-caption text-white display-4" href="<?= base_url('auth/home'); ?>">
                            BBRVPD</a></span>
                </div>
            </div>
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav nav-dropdown" data-app-modern-menu="true">
                    <li class="nav-item">
                        <a class="nav-link link text-danger display-4" href="<?= base_url('auth'); ?>"><span class="mbri-briefcase mbr-iconfont mbr-iconfont-btn"></span>

                            Lowongan Kerja<br></a>
                    </li>
                </ul>
                <div class="navbar-buttons mbr-section-btn"><a class="btn btn-sm btn-primary display-4" href="<?= base_url('auth'); ?>"><span class="mobi-mbri mobi-mbri-login mbr-iconfont mbr-iconfont-btn"></span>Masuk
                    </a> <a class="btn btn-sm btn-secondary display-4" href="<?= base_url('auth/registration'); ?>"><span class="mbri-user mbr-iconfont mbr-iconfont-btn"></span>Daftar</a></div>
            </div>
        </nav>
    </section>

    <section class="engine"><a href="">build your own site</a></section>
    <section class="carousel slide cid-rxUp7iy4xy" data-interval="false" id="slider1-7">



        <div class="full-screen">
            <div class="mbr-slider slide carousel" data-pause="true" data-keyboard="false" data-ride="false" data-interval="false">
                <ol class="carousel-indicators">
                    <li data-app-prevent-settings="" data-target="#slider1-7" class=" active" data-slide-to="0"></li>
                    <li data-app-prevent-settings="" data-target="#slider1-7" data-slide-to="1"></li>


                </ol>
                <div class="carousel-inner" role="listbox">
                    <div class="carousel-item slider-fullscreen-image active" data-bg-video-slide="false" style="background-image: url(<?= base_url('assets/'); ?>landingpage/images/waww.png);">
                        <div class="container container-slide">
                            <div class="image_wrapper"><img src="<?= base_url('assets/'); ?>landingpage/images/waww.png">
                                <div class="carousel-caption justify-content-center">
                                    <div class="col-10 align-right"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="carousel-item slider-fullscreen-image" data-bg-video-slide="false" style="background-image: url(<?= base_url('assets/'); ?>landingpage/images/mantap.png);">
                        <div class="container container-slide">
                            <div class="image_wrapper"><img src="<?= base_url('assets/'); ?>landingpage/images/mantap.png">
                                <div class="carousel-caption justify-content-center">
                                    <div class="col-10 align-right"></div>
                                </div>
                            </div>
                        </div>
                    </div>


                </div><a data-app-prevent-settings="" class="carousel-control carousel-control-prev" role="button" data-slide="prev" href="#slider1-7"><span aria-hidden="true" class="mbri-left mbr-iconfont"></span><span class="sr-only">Previous</span></a><a data-app-prevent-settings="" class="carousel-control carousel-control-next" role="button" data-slide="next" href="#slider1-7"><span aria-hidden="true" class="mbri-right mbr-iconfont"></span><span class="sr-only">Next</span></a>
            </div>
        </div>

    </section>

    <section class="counters4 counters cid-rxUt8b9ZIN" id="counters4-c">





        <div class="container pt-4 mt-2">
            <h2 class="mbr-section-title pb-3 align-center mbr-fonts-style display-2">Kenapa Memilih Kami?</h2>

            <div class="media-container-row">
                <div class="media-block m-auto" style="width: 60%;">
                    <div class="mbr-figure">
                        <img src="<?= base_url('assets/'); ?>landingpage/images/3-1024x512.jpg" alt="" title="">
                    </div>
                </div>
                <div class="cards-block">
                    <div class="cards-container">
                        <div class="card px-3 align-left col-12">
                            <div class="panel-item p-4 d-flex align-items-start">
                                <div class="card-img pr-3">
                                    <h3 class="img-text d-flex align-items-center justify-content-center">
                                        1
                                    </h3>
                                </div>
                                <div class="card-text">
                                    <h4 class="mbr-content-title mbr-bold mbr-fonts-style display-7">Terlatih/Memiliki Kompetensi</h4>

                                </div>
                            </div>
                        </div>
                        <div class="card px-3 align-left col-12">
                            <div class="panel-item p-4 d-flex align-items-start">
                                <div class="card-img pr-3">
                                    <h3 class="img-text d-flex align-items-center justify-content-center">
                                        2
                                    </h3>
                                </div>
                                <div class="card-text">
                                    <h4 class="mbr-content-title mbr-bold mbr-fonts-style display-7">Memiliki Mental Pekerja</h4>

                                </div>
                            </div>
                        </div>
                        <div class="card px-3 align-left col-12">
                            <div class="panel-item p-4 d-flex align-items-start">
                                <div class="card-img pr-3">
                                    <h3 class="img-text d-flex align-items-center justify-content-center">
                                        3
                                    </h3>
                                </div>
                                <div class="card-text">
                                    <h4 class="mbr-content-title mbr-bold mbr-fonts-style display-7">Tenaga Kerja Siap Pakai</h4>

                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="cid-rxUsyTKiL6" id="header2-b">



        <div class="mbr-overlay" style="opacity: 1; background-color:rgb(35, 35, 35); background-image: url(<?= base_url('assets/'); ?>landingpage/images/3-1600x800.jpg);">

        </div>


        <div class="container align-center">
            <div class="row justify-content-md-center">
                <div class="mbr-white col-md-10">

                    <h1 class="mbr-section-title mbr-bold pb-3 mbr-fonts-style display-1">
                        Daftarkan Segera Dirimu</h1>

                    <p class="mbr-text pb-3 mbr-fonts-style display-5">Perlu tenaga kerja penyandang disabilitas? atau mencari &nbsp;lowongan kerja untuk penyandang disabilitas? disinilah tempatnya daftarkan &nbsp;dirimu sekarang&nbsp;</p>
                    <div class="mbr-section-btn"><a class="btn btn-md btn-success display-4" href="http://localhost/login/auth/registrasiperusahaan">Perusahaan</a>
                        <a class="btn btn-md btn-danger display-4" href="http://localhost/login/auth/registration">Pencari Kerja</a></div>
                </div>
            </div>
        </div>

    </section>
    <section class="mbr-section content5 cid-rxUu1m572B" id="content5-e">





        <div class="container">
            <div class="media-container-row">
                <div class="title col-12 col-md-8">
                    <h2 class="align-center mbr-bold mbr-white pb-3 mbr-fonts-style display-1"><span style="font-weight: normal;">JENIS KOMPETENSI &nbsp;</span></h2>



                </div>
            </div>
        </div>
    </section>

    <section class="mbr-gallery mbr-slider-carousel cid-ryVE0pvNhJ" id="gallery4-q">



        <div class="container">
            <div>
                <!-- Gallery -->
                <div class="gallery-row">
                    <div class="mbr-gallery-layout-default">
                        <div>
                            <div class="row-first row justify-content-center m-0">
                                <div class="mbr-gallery-item col-lg-4 col-md-4 col-sm-12 p-2" data-video-url="false">
                                    <div href="#lb-gallery4-q" data-slide-to="0" data-toggle="modal"><img src="<?= base_url('assets/'); ?>landingpage/images/gambar1-1-484x999-484x999.jpg" alt="" title=""><span class="icon-focus"></span></div>
                                </div>
                                <div class="mbr-gallery-item col-lg-4 col-md-4 col-sm-12 p-2" data-video-url="false">
                                    <div href="#lb-gallery4-q" data-slide-to="1" data-toggle="modal"><img src="<?= base_url('assets/'); ?>landingpage/images/gambar2-484x999-484x999.jpg" alt="" title=""><span class="icon-focus"></span></div>
                                </div>
                                <div class="mbr-gallery-item col-lg-4 col-md-4 col-sm-12 p-2" data-video-url="false">
                                    <div href="#lb-gallery4-q" data-slide-to="2" data-toggle="modal"><img src="<?= base_url('assets/'); ?>landingpage/images/gambar3-1-484x999-484x999.jpg" alt="" title=""><span class="icon-focus"></span></div>
                                </div>
                            </div>
                            <div class="row-second row justify-content-center m-0">
                                <div class="mbr-gallery-item col-lg-4 col-md-4 col-sm-12 p-2" data-video-url="false">
                                    <div href="#lb-gallery4-q" data-slide-to="3" data-toggle="modal"><img src="<?= base_url('assets/'); ?>landingpage/images/gambar4-1-484x999-484x999.jpg" alt="" title=""><span class="icon-focus"></span></div>
                                </div>
                                <div class="mbr-gallery-item col-lg-4 col-md-4 col-sm-12 p-2" data-video-url="false">
                                    <div href="#lb-gallery4-q" data-slide-to="4" data-toggle="modal"><img src="<?= base_url('assets/'); ?>landingpage/images/gambar5-1-484x999-484x999.jpg" alt="" title=""><span class="icon-focus"></span></div>
                                </div>
                                <div class="mbr-gallery-item col-lg-4 col-md-4 col-sm-12 p-2" data-video-url="false">
                                    <div href="#lb-gallery4-q" data-slide-to="5" data-toggle="modal"><img src="<?= base_url('assets/'); ?>landingpage/images/picture4-484x999-484x999.jpg" alt="" title=""><span class="icon-focus"></span></div>
                                </div>
                            </div>
                        </div>
                        <div class="clearfix"></div>
                    </div>
                </div><!-- Lightbox -->
                <div data-app-prevent-settings="" class="mbr-slider modal fade carousel slide" tabindex="-1" data-keyboard="true" data-interval="false" id="lb-gallery4-q">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-body">
                                <div class="carousel-inner">
                                    <div class="carousel-item active"><img src="<?= base_url('assets/'); ?>landingpage/images/gambar1-1-484x999.jpg" alt="" title=""></div>
                                    <div class="carousel-item"><img src="<?= base_url('assets/'); ?>landingpage/images/gambar2-484x999.jpg" alt="" title=""></div>
                                    <div class="carousel-item"><img src="<?= base_url('assets/'); ?>landingpage/images/gambar3-1-484x999.jpg" alt="" title=""></div>
                                    <div class="carousel-item"><img src="<?= base_url('assets/'); ?>landingpage/images/gambar4-1-484x999.jpg" alt="" title=""></div>
                                    <div class="carousel-item"><img src="<?= base_url('assets/'); ?>landingpage/images/gambar5-1-484x999.jpg" alt="" title=""></div>
                                    <div class="carousel-item"><img src="<?= base_url('assets/'); ?>landingpage/images/picture4-484x999.jpg" alt="" title=""></div>
                                </div><a class="carousel-control carousel-control-prev" role="button" data-slide="prev" href="#lb-gallery4-q"><span class="mbri-left mbr-iconfont" aria-hidden="true"></span><span class="sr-only">Previous</span></a><a class="carousel-control carousel-control-next" role="button" data-slide="next" href="#lb-gallery4-q"><span class="mbri-right mbr-iconfont" aria-hidden="true"></span><span class="sr-only">Next</span></a><a class="close" href="#" role="button" data-dismiss="modal"><span class="sr-only">Close</span></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </section>

    <section class="carousel slide testimonials-slider cid-rxUwpRVvA0" data-interval="false" id="testimonials-slider1-j">





        <div class="container text-center">
            <h2 class="pb-5 mbr-fonts-style display-2">
                Testimoni&nbsp;</h2>

            <div class="carousel slide" role="listbox" data-pause="true" data-keyboard="false" data-ride="carousel" data-interval="5000">
                <div class="carousel-inner">


                    <div class="carousel-item">
                        <div class="user col-md-8">
                            <div class="user_image">
                                <img src="<?= base_url('assets/'); ?>landingpage/images/foto-andrihp-3x4-216x288.jpg" alt="" title="">
                            </div>
                            <div class="user_text pb-3">
                                <p class="mbr-fonts-style display-7">"Memperkerjakan tenaga kerja penyandang disabilitas dapat memotivasi<br>semangat pekerja yang lainnya".&nbsp;</p>
                            </div>
                            <div class="user_name mbr-bold pb-2 mbr-fonts-style display-7">
                                Andri Haryadi Pratama</div>
                            <div class="user_desk mbr-light mbr-fonts-style display-7">PT Sarana Solusindo Informatika</div>
                        </div>
                    </div>
                    <div class="carousel-item">
                        <div class="user col-md-8">
                            <div class="user_image">
                                <img src="<?= base_url('assets/'); ?>landingpage/images/02-400x581.jpg" alt="" title="">
                            </div>
                            <div class="user_text pb-3">
                                <p class="mbr-fonts-style display-7">"Web ini memperbesar peluang kesempatan kerja bagi para penyandang disabilitas&nbsp;<br>dan memudahkan bagi perusahaan dalam memperoleh tenaga kerja penyandang disabilitas".</p>
                            </div>
                            <div class="user_name mbr-bold pb-2 mbr-fonts-style display-7">Luhur Yuwono Dwi Raharjo</div>
                            <div class="user_desk mbr-light mbr-fonts-style display-7">KEPALA BIDANG BIMBINGAN TEKNIS DAN EVALUASI BBRVPD CIBINONG</div>
                        </div>
                    </div>
                </div>

                <div class="carousel-controls">
                    <a class="carousel-control-prev" role="button" data-slide="prev">
                        <span aria-hidden="true" class="mbri-arrow-prev mbr-iconfont"></span>
                        <span class="sr-only">Previous</span>
                    </a>

                    <a class="carousel-control-next" role="button" data-slide="next">
                        <span aria-hidden="true" class="mbri-arrow-next mbr-iconfont"></span>
                        <span class="sr-only">Next</span>
                    </a>
                </div>
            </div>
        </div>
    </section>

    <section class="cid-rxUwwmndDD" id="footer2-k">





        <div class="container">
            <div class="media-container-row content mbr-white">
                <div class="col-12 col-md-3 mbr-fonts-style display-7">
                    <p class="mbr-text">
                        <strong>Address</strong>
                        <br> <br>BBRVPD-NVRC Cibinong, Jl. SKB No.5, Karadenan, Cibinong, Bogor, West Java 16913&nbsp;<br><br><br></p>
                </div>
                <div class="col-12 col-md-3 mbr-fonts-style display-4">
                    <p class="mbr-text">
                        <strong>Links</strong>
                        &nbsp;<br><br><a href="https://bbrvbd.kemsos.go.id/" class="text-white">BBRVPD</a><br>
                        <a href="http://www.kemsos.go.id" class="text-white">KEMENSOS</a><br><br><br><br></p>
                </div>
                <div class="col-12 col-md-6">
                    <div class="google-map"><iframe frameborder="0" style="border:0" src="https://www.google.com/maps/embed/v1/place?key=AIzaSyAEIpgj38KyLFELm2bK9Y7krBkz1K-cMq8&amp;q=place_id:ChIJmeDawdDDaS4RLRHyhnbQQL0" allowfullscreen=""></iframe></div>
                </div>
            </div>
            <div class="footer-lower">
                <div class="media-container-row">
                    <div class="col-sm-12">
                        <hr>
                    </div>
                </div>
                <div class="media-container-row mbr-white">
                    <div class="col-sm-6 copyright">
                        <p class="mbr-text mbr-fonts-style display-7">
                            © Copyright 2019 Pradiptadh - All Rights Reserved
                        </p>
                    </div>
                    <div class="col-md-6">

                    </div>
                </div>
            </div>
        </div>
    </section>


    <!--ini buat landingpage -->

    <script src="<?= base_url('assets/'); ?>landingpage/web/assets/jquery/jquery.min.js"></script>
    <script src="<?= base_url('assets/'); ?>landingpage/popper/popper.min.js"></script>
    <script src="<?= base_url('assets/'); ?>landingpage/tether/tether.min.js"></script>
    <script src="<?= base_url('assets/'); ?>landingpage/bootstrap/js/bootstrap.min.js"></script>
    <script src="<?= base_url('assets/'); ?>landingpage/dropdown/js/nav-dropdown.js"></script>
    <script src="<?= base_url('assets/'); ?>landingpage/dropdown/js/navbar-dropdown.js"></script>
    <script src="<?= base_url('assets/'); ?>landingpage/touchswipe/jquery.touch-swipe.min.js"></script>
    <script src="<?= base_url('assets/'); ?>landingpage/ytplayer/jquery.mb.ytplayer.min.js"></script>
    <script src="<?= base_url('assets/'); ?>landingpage/smoothscroll/smooth-scroll.js"></script>
    <script src="<?= base_url('assets/'); ?>landingpage/bootstrapcarouselswipe/bootstrap-carousel-swipe.js"></script>
    <script src="<?= base_url('assets/'); ?>landingpage/viewportchecker/jquery.viewportchecker.js"></script>
    <script src="<?= base_url('assets/'); ?>landingpage/masonry/masonry.pkgd.min.js"></script>
    <script src="<?= base_url('assets/'); ?>landingpage/imagesloaded/imagesloaded.pkgd.min.js"></script>
    <script src="<?= base_url('assets/'); ?>landingpage/mbr-testimonials-slider/mbr-testimonials-slider.js"></script>
    <script src="<?= base_url('assets/'); ?>landingpage/vimeoplayer/jquery.mb.vimeo_player.js"></script>
    <script src="<?= base_url('assets/'); ?>landingpage/theme/js/script.js"></script>
    <script src="<?= base_url('assets/'); ?>landingpage/gallery/player.min.js"></script>
    <script src="<?= base_url('assets/'); ?>landingpage/gallery/script.js"></script>
    <script src="<?= base_url('assets/'); ?>landingpage/slidervideo/script.js"></script>



</body>

</html>